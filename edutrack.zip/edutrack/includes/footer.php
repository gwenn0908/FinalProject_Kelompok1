    </main>
    <footer class="main-footer">
        <div class="footer-content">
            <p>&copy; 2025 EduTrack - Learning Productivity Support System</p>
            <p class="sdg-notice">
                <i class="fas fa-graduation-cap"></i> Supporting SDG 4: Quality Education
            </p>
        </div>
    </footer>
    <script src="../assets/js/main.js"></script>
    <?php if (isset($extra_js)) echo $extra_js; ?>
</body>
</html>

